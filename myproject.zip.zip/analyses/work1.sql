select * from {{ ref("bronze_hosts") }}
